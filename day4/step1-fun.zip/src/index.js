import React, { Component } from 'react';
import ReactDOM from 'react-dom';

// let FirstComp = () => <h1> Welcome to your life </h1>;

class FirstComp extends Component{
    title = "Welcome to your life";
    render(){
        return <>
                <h1>{ this.title }</h1>
                <h1>{ this.title }</h1>
                <label htmlFor="username">User Name </label>
                <input defaultValue="asdf" id="username"/>
                <div className=''></div>

               </>
    }
}

ReactDOM.render(<FirstComp/>, document.getElementById("root"));
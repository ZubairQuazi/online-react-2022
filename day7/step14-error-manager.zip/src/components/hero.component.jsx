import { Component } from "react";

class HeroComponent extends Component{

    state = {
        power : 0
    }

    constructor(){
        super();

        this.state = {
            power : Math.round( Math.random() * 10 )
        }
    }

    render(){
        if( this.state.power <= 5){
            throw new Error("Hero is not ready to fight");
        }else{
            return <div>
                        <h2>Hero Component</h2>
                        <h3>Power is { this.state.power }</h3>
                   </div>
        }
    }
}


export default HeroComponent;
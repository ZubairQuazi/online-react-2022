import { Component } from "react";
import HeroComponent from "./components/hero.component";
import ErrorManager from "./error.manager";

class App extends Component{

    render(){
        return <div className="container">
                <h2>Error Boundries</h2>
                <hr/>
                <ErrorManager>
                    <HeroComponent/>
                </ErrorManager>
                <ErrorManager>
                    <HeroComponent/>
                </ErrorManager>
                <ErrorManager>
                    <HeroComponent/>
                </ErrorManager>
                <ErrorManager>
                    <HeroComponent/>
                </ErrorManager>
                <ErrorManager>
                    <HeroComponent/>
                </ErrorManager>
               </div>
    }
}

export default App;
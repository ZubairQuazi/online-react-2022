import { Component } from "react";

class ErrorManager extends Component{
    state = {
        hasError : false,
        message : ''
    }
    componentDidCatch(error){
        this.setState({
            hasError : true,
            message : error+""
        })
    }
    render(){
        if( this.state.hasError ){
            return <h3> Hero needs rest { this.state.message } </h3>
        }else{
            return this.props.children
        }
    }
}

export default ErrorManager;
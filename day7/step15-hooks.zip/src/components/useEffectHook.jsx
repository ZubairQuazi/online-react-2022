import { useEffect } from "react";

let UseEffectHook = (props)=>{

    useEffect(()=>{
        console.log("Component did mount")
    },[])

    useEffect(()=>{
        console.log("Component did update")
    },[props.power])

    useEffect(()=>{
       return ()=>  console.log("Component did unmount")
    },[])


    return<div>
                <h2>Use Effect Hook</h2>
                <h3>Power : { props.power }</h3>
            </div>
}

export default UseEffectHook;
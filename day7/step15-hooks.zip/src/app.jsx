import { Component } from "react";
import UseEffectHook from "./components/useEffectHook";
import UseStateHook from "./components/usestatehook";
class App extends Component{
    state = {
        power : 0,
        show : true
    }
    render(){
        return <div className="container">
                <h2>Hooks</h2>
                <button onClick={ ()=> this.setState({ power : this.state.power + 1 })}>Increase Power</button>
                <button onClick={ ()=> this.setState({ show : !this.state.show })}>Show / Hide</button>
                <hr/>
                <UseStateHook/>
                <hr/>
                { this.state.show && <UseEffectHook power={ this.state.power }/> }
               </div>
    }
}

export default App;
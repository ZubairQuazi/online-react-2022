import { Component } from "react";
import withPower from "../withPower";

class PowerHoverComponent extends Component{
    render(){
        return <div style={ { border : "5px dotted grey", padding : "10px", margin : "10px" } }>
                <h2>Power Hover Components</h2>
                <h3>Power is : { this.props.power }</h3>
                <h4>Title : { this.props.title } | version : { this.props.version } </h4>
                <h4>Created on : { this.props.mfgDate }</h4>
                <div style={ { width : "250px", backgroundColor : "crimson", textAlign : "center", lineHeight : "50px", height : "50px", color : "papayawhip", } } onMouseMove={ this.props.increasePower }>Move Mouse to increase Power</div>
               </div>
    }
}

export default withPower(PowerHoverComponent)
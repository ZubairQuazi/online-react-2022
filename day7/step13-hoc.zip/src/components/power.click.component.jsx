import { Component } from "react";
import withPower from "../withPower";

class PowerClickComponent extends Component{

    render(){
        return <div  style={ { border : "5px dotted grey", padding : "10px", margin : "10px" } }>
                <h2>Power Click Components</h2>
                <h3>Power is : { this.props.power }</h3>
                <h4>Title : { this.props.title } | version : { this.props.version } </h4>
                <h4>Created on : { this.props.mfgDate }</h4>
                <button onClick={ this.props.increasePower }>Increase Power</button>
               </div>
    }
}

export default withPower(PowerClickComponent)
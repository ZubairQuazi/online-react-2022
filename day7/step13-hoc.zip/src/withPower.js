import { Component } from "react";

let withPower = ( OriginalComponent  )=>{

    class TempComp extends Component{
        state = {
            power : 0
        }
        increasePower = ()=>{
            this.setState({
                power : this.state.power + 1
            })
        }
        /*         
            render(){
            return <OriginalComponent 
            title={ this.props.title }
            version={ this.props.version }
            increasePower={ this.increasePower } 
            power={ this.state.power }/>
        } */
        render(){
            return <OriginalComponent 
            { ...this.props }
            increasePower={ this.increasePower } 
            power={ this.state.power }/>
        }
    }

    return TempComp;
}

export default withPower;
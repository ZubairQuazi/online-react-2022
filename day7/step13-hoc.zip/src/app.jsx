import { Component } from "react";
import PowerClickComponent from "./components/power.click.component";
import PowerHoverComponent from "./components/power.hover.component";
import SecondPowerClickComponent from "./components/secondpower.click.component";

class App extends Component{

    render(){
        return <div className="container">
                <h2>Higher Order Components</h2>
                <hr/>
                <PowerClickComponent mfgDate="1st Jan 2022" title="Click Component" version={ 101 }/>
                <br/>
                <SecondPowerClickComponent mfgDate="5th Jan 2022" title="2nd Click Component" version={ 201 }/>
                <br/>
                <PowerHoverComponent mfgDate="30th Jan 2022" title="Hover Component" version={ 301 }/>
               </div>
    }
}

export default App;
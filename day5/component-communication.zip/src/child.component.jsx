import React, { Component } from "react";

class ChildComp extends Component{
    ti = React.createRef();
    render(){
        let styleConfig = { 
            border : "1px solid grey", 
            padding : "10px", 
            width : "300px", 
            margin : '10px',
            float : "left"
        } ;
        return <div style={ styleConfig }>
                    <h2>Child Component</h2>
                    <hr/>
                    <h3>Title : { this.props.title }</h3>
                    <h3>Power : { this.props.pow }</h3>
                    <button onClick={ this.props.powerHandler }>Increase Parent Power</button>
                    <hr />
                    <input ref={ this.ti } type="text" />
                    <button onClick={ ()=>this.props.titleHandler(this.ti.current.value) }>Set Parent Title</button>
                </div>
    }
}

export default ChildComp;
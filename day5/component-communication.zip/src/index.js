import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './child.component';

class App extends Component{
    state = {
        power : 0,
        title : "My Online Application"
    };

    increasePower = ()=>{
        this.setState({ power : this.state.power + 1})
    }

    changeTitle = (ntitle)=>{
        this.setState({
            title : ntitle
        })
    }

    render(){
        return <div>
                <h1>Component Communication : { this.state.title }</h1>
                <h1>Power is : { this.state.power }</h1>
                <button onClick={  this.increasePower }>Increase Power </button>
                <hr/>
                <ChildComp titleHandler={ this.changeTitle } powerHandler={ this.increasePower } title={ this.state.title } pow={ this.state.power } />
               </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));
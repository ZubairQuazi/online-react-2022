import {Fragment} from "react";

function List(props){
    return <Fragment>
            <h2>{ props.children } | Version : { props.version }</h2>
            <ol>
                {
                    props.heroes.map((val,idx)=><li key={idx}>{ val }</li>)
                }
             </ol>
            </Fragment>
};

// export { List };
export default List;
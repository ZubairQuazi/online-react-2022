import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import List from './components/list.component';

/* class HeroList extends Component{
    avengers = ['Ironman','Hulk','Black Widow','Thor','Hawkeye','Groot','Antman'];
    justicleague = ['Batman','Superman','Flash','Wonder Women','Cyborg','Green Arrow'];
    indicheroes = ['Shaktiman','Chota Bheem','Sabu','Minnal Murali','Chacha Chaudari','Tenali Rama','Krish'];
    version = 1001;
    constructor(){
        super();
        setTimeout(()=>{
            this.version = 1002;
            console.log('version now is ', this.version);
            // this.render();
            this.forceUpdate();
        },4000);
    }
    render(){
        return <div>
                    <List version={ this.version } heroes={this.avengers} >Avengers</List>
                    <List version={ this.version } heroes={this.justicleague} >Justice League</List>
                    <List version={ this.version } heroes={this.indicheroes} >Indic Comic Heroes</List>
                </div>
    }
} */

class HeroList extends Component{
    state = {
        avengers : ['Ironman','Hulk','Black Widow','Thor','Hawkeye','Groot','Antman'],
        justicleague : ['Batman','Superman','Flash','Wonder Women','Cyborg','Green Arrow'],
        indicheroes : ['Shaktiman','Chota Bheem','Sabu','Minnal Murali','Chacha Chaudari','Tenali Rama','Krish'],
        version : 1001
    }
    constructor(){
        super();
        setTimeout(()=>{
          /*  this.setState({
               version : this.state.version + 1
           }) */
           this.setState(function(){
               return {
                version : this.state.version + 1
            }
           })
        },4000);
    }
    render(){
        return <div>
                    <List version={ this.state.version } heroes={this.state.avengers} >Avengers</List>
                    <List version={ this.state.version } heroes={this.state.justicleague} >Justice League</List>
                    <List version={ this.state.version } heroes={this.state.indicheroes} >Indic Comic Heroes</List>
                </div>
    }
}


ReactDOM.render(
<HeroList/>, 
document.getElementById("root"));
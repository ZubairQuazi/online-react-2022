import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';

class MainApp extends Component{
    state = {
        title : 'Edelweiss Application',
        version : 0
    }
    increaseVersion(){
      this.setState(
        { version : this.state.version + 1 }
        )
    }
    modifyTitle(msg){
      this.setState({
        title : msg
      })
    }
    render(){
        return <div className='container'>
                   <h1>Title : { this.state.title }</h1>
                   <h2>Version : { this.state.version }</h2>
                   <button onClick={ ()=>this.increaseVersion() }>Increase Version</button>
                   <hr/>
                   <ChildComp changeTitle={ (ntitle)=>this.modifyTitle(ntitle) } increaseHandler={ ()=>this.increaseVersion() } ver={ this.state.version } />
               </div>
    }
}


ReactDOM.render(<MainApp/>,document.getElementById("root"));
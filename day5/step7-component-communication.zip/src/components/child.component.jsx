import React, { Component } from 'react';

class ChildComp extends Component{
    state = {};
    ti1 = React.createRef();
    changeParentTitle(){
        // alert("you clicked the button");
        this.props.changeTitle(this.ti1.current.value);
        this.ti1.current.value = '';
    }
    render(){
        return <div>
                   <h1>Child Component</h1>
                   <h2>Version : { this.props.ver }</h2>
                   <button onClick={ ()=> this.props.increaseHandler() }>Incease Parent's Version</button>
                   <br/>
                   <br/>
                   <input ref={ this.ti1 } type="text" />
                   <button onClick={ ()=> this.changeParentTitle() }>Change Parent's Title</button>
               </div>
    }
}

export default ChildComp;

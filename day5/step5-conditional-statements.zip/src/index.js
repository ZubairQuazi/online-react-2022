import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        title : 'Edelweiss Application',
        version : 1001,
        showTerms : false
    }
    render(){
        return <div>
                   <h1>Title : { this.state.title }</h1>
                   <h2>Version : { this.state.version }</h2>
                   <hr/>
                   { 
                   this.state.showTerms 
                   ? 
                   <fieldset>
                       <legend>Terms & Conditions</legend>
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores dignissimos harum vero delectus, ducimus saepe repudiandae, ea cupiditate illo placeat quod assumenda rerum sit eum amet quos. Placeat, vero quia!
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores dignissimos harum vero delectus, ducimus saepe repudiandae, ea cupiditate illo placeat quod assumenda rerum sit eum amet quos. Placeat, vero quia!
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores dignissimos harum vero delectus, ducimus saepe repudiandae, ea cupiditate illo placeat quod assumenda rerum sit eum amet quos. Placeat, vero quia!
                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maiores dignissimos harum vero delectus, ducimus saepe repudiandae, ea cupiditate illo placeat quod assumenda rerum sit eum amet quos. Placeat, vero quia!
                        <br/>
                        <button onClick={ ()=> this.setState({ showTerms : false }) }>hide terms</button>
                   </fieldset> 
                   : 
                   <label>Show Terms and Conditions : <input type="checkbox" onChange={ ()=> this.setState({ showTerms : true }) } /></label> 
                   }
               </div>     
    }
}


ReactDOM.render(<MainApp/>,document.getElementById("root"));
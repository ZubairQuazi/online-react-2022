import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        title : 'Edelweiss Application',
        version : 0
    }
    increaseVersion(){
       /*  this.setState({
            version : this.state.version + 1
        });
        console.log(this.state.version); */

/*         this.setState({
            version : this.state.version + 1
        },function(){
            console.log(this.state.version);
        }); */
        
        this.setState(
        (currentState, props)=>{ 
            return { 
                version : currentState.version + 1 
            } 
        },
        ()=> console.log(this.state.version));
    }
    render(){
        return <div>
                   <h1>Title : { this.state.title }</h1>
                   <h2>Version : { this.state.version }</h2>
                   <hr/>
                   <button onClick={()=>this.increaseVersion() }>Increase Version</button>
               </div>
    }
}


ReactDOM.render(<MainApp/>,document.getElementById("root"));
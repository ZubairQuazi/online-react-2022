import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        title : 'Edelweiss Application',
        version : 0
    }
    //------------------------------
    vi = React.createRef();
    //------------------------------
    constructor(){
        super();
        this.increaseVersionAgain = this.increaseVersionAgain.bind(this);
    }
    increaseVersion(){
        this.setState({
            version : this.state.version + 1
        })
    }
    increaseVersionAgain(){
        this.setState({
            version : this.state.version + 1
        })
    }
    increaseVersionFromInput(evt){
        this.setState({
            version : evt.target.value
        })
    }
    increaseVersionBy(){
        this.setState({
            version : this.vi.current.value
        })
    }
    render(){
        return <div>
                   <h1>Title : { this.state.title }</h1>
                   <h2>Version : { this.state.version }</h2>
                   <hr/>
                   <button onClick={ this.increaseVersion.bind(this) }>Increase Version</button>
                   <button onClick={ ()=>{ this.increaseVersion()  }}>Increase Version</button>
                   <button onClick={ this.increaseVersionAgain }>Increase Version</button>
                   <br/>
                   <input value={ this.state.version } onChange={  evt => this.increaseVersionFromInput(evt) } type="range"/>
                   <br/>
                   <input ref={this.vi} min="0" max="100" type="number"/>
                   <button onClick={ ()=>this.increaseVersionBy() }>Set Version</button>
               </div>
    }
}


ReactDOM.render(<MainApp/>,document.getElementById("root"));
import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
<h1>Welcome to your life</h1>, 
document.getElementById("root"));
import ReactDOM from 'react-dom';
import Mainapp from './mainapp.component';

ReactDOM.render(<Mainapp/>, document.getElementById("root"))
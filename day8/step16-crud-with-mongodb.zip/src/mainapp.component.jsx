import UseEffectForAjax from "./components/useEffectHook.component";

let Mainapp = ()=>{
    return <div className="container">
                <h1>My Application</h1>
                <hr/>
                <UseEffectForAjax/>
            </div>
}

export default Mainapp;
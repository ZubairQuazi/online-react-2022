import { Component } from "react";
import axios from 'axios';

class MainApp extends Component{
    // Using AJAX to load external data
    state = {
        users : []
    }
    componentDidMount(){
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((res)=>{
            this.setState({
                users : res.data
            })
        }).catch((err)=>{
            console.log(err);
        })
    }
    render(){
        return <div>
                    <h1>Main Application </h1>
                    <ul>{
                        this.state.users.map((val)=> <li key={val.id}>{val.name}</li>)
                       /*  this.state.users.forEach((val)=>{
                            return <li key={val.id}>{ val.name }</li>
                        }) */
                        }</ul>
               </div>
    }
}

export default MainApp;
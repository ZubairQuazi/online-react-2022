let condition = function(){
    return "palevioletred";
};

let externalJSStyle = {
    color : "maroon", 
    backgroundColor : condition(), 
    padding : "10px", 
    margin:"5px",
    borderRadius : "20px",
    border: "5px solid palegoldenrod"
}

export default externalJSStyle
import { Component } from "react";
import externalJSStyle from "./mystyle";
import "./mystyle.css";

class MainApp extends Component{
   // how to use styles    
    render(){
        let mystyle = { color : "red", backgroundColor : "black", padding : "10px", margin:"5px"};

        return <div>
                    <h1>Main Application</h1>
                    <p style={ mystyle }>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab consequatur excepturi laborum quasi consectetur nobis veritatis possimus non qui nihil sed necessitatibus et ea sequi, distinctio at illo quia incidunt.
                    </p>
                    <p  style={ externalJSStyle }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio, et doloremque. Dolor explicabo ullam ea at mollitia eius laborum! Atque rem sequi numquam alias quasi ab et! Voluptate, at corporis.
                    </p>
                    <p className="box">
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fugiat quo qui reprehenderit! Nam voluptas dicta cupiditate neque tempore ipsum natus eius! Enim animi omnis ut ab! Aliquam esse assumenda perferendis!
                    </p>
                    <p className="box">
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fugiat quo qui reprehenderit! Nam voluptas dicta cupiditate neque tempore ipsum natus eius! Enim animi omnis ut ab! Aliquam esse assumenda perferendis!
                    </p>
                    <p>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Fugiat quo qui reprehenderit! Nam voluptas dicta cupiditate neque tempore ipsum natus eius! Enim animi omnis ut ab! Aliquam esse assumenda perferendis!
                    </p>
                    <p  style={ externalJSStyle }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum quis facilis temporibus tempore omnis necessitatibus consequuntur quaerat fugiat odit iure natus, laboriosam modi praesentium officiis qui rem repellendus ipsa sunt.
                    </p>
               </div>
    }
}

export default MainApp;
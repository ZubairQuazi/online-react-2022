import { Component } from "react";

class ChildComp extends Component{
    state = {
        title : "default child title",
        version : 1
    }
    undolist = [];
    constructor(){
        super();
        /*         
        this.state = {
            title : "Changed by constructor",
            version : 5
        } 
        */
        console.log("ChildComp's constructor was called");
    }
    static getDerivedStateFromProps(currentProps, currentState){
        console.log(currentProps, currentState);
        console.log("ChildComp's getDerivedStateFromProps was called");
        return {
            title : "changed by getDerivedStateFromProps",
            version : currentProps.ver * 2
        }
    } 
    componentDidMount(){
        console.log("ChildComp's componentDidMount was called");
    }
    shouldComponentUpdate(...args){
        console.log("ChildComp's shouldComponentUpdate was called");
        console.log(args[0],args[1], args[2]);
        if(args[0].ver < 100){
            return false
        }else{
            return true
        }
    }
    getSnapshotBeforeUpdate(){
        console.log("ChildComp's getSnapshotBeforeUpdate was called");
        return {
            message : this.state.title
        }
    }
    componentDidUpdate(currentProps, currentState, snapshot){
        console.log("ChildComp's componentDidUpdate was called");
        this.undolist.push({
            currentPros : currentProps,
            currentState : currentState,
            snapshot : snapshot
        });
        console.log(this.undolist.length);
        console.log( this.undolist );
    }
    render(){
        console.log("ChildComp's render was called");
        return <div>
                    <h1>Child Component</h1>
                    <hr/>
                    <h2>Title now is : { this.state.title }</h2>
                    <h2>Version now is : { this.state.version }</h2>
                    <h2>Title from prop is sent from parent : { this.props.title }</h2>
                    <h2>Version from prop is sent from parent : { this.props.ver }</h2>
                </div>
    }
}

export default ChildComp;
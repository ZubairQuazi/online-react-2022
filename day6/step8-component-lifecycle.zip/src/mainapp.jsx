import { Component } from "react";
import ChildComp from "./components/child.component";

class MainApp extends Component{
    state = {
        title : "default title",
        version : 100
    }
    constructor(){
        super();
        console.log("MainApp's constructor was called");
    }
    static getDerivedStateFromProps(){
        console.log("MainApp's getDerivedStateFromProps was called");
        return true
    } 
    componentDidMount(){
        console.log("MainApp's componentDidMount was called");
    }
    render(){
        console.log("MainApp's render was called");
        return <div>
                    <h1>Main Application</h1>
                    <h2>Title now is : { this.state.title }</h2>
                    <h2>Version now is : { this.state.version }</h2>
                    <button onClick={ ()=> this.setState({ version : Math.round( Math.random() * 1000 ) })}>Change Version</button>
                    <hr/>
                    <ChildComp ver={ this.state.version } title={ this.state.title }/>
                </div>
    }
}

export default MainApp;
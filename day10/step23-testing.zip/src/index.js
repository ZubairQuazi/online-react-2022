import ReactDOM from 'react-dom';
import MainApp from './MainApp';

ReactDOM.render(<MainApp/>, document.getElementById("root"));
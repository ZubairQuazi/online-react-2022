/* let MainApp = ()=>{
    return<div className="container">
                <h1>Routing 101</h1>
           </div>
} */

import { Component } from "react";

class MainApp extends Component{
    state = {
        power : 5
    }
    render(){
        return <div>
                    <h1>Power is : { this.state.power }</h1>
                </div>
    }
}

export default MainApp;
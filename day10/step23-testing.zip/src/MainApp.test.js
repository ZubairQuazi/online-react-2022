import MainApp from "./MainApp";

describe("Testing for Power",()=>{
    let app = null;
    beforeAll(()=>{
        app = new MainApp();
        console.log("beforeAll was called");
    });
    beforeEach(()=>{
        console.log("beforeEach was called")
    });
    afterEach(()=>{
        console.log("afterEach was called")
    });
    afterAll(()=>{
        console.log("afterAll was called")
    });

    it("Should have Power",function(){
        expect(app.state.power).toBeDefined();
    })
    it("Power shoule be less than 10",function(){
        expect(app.state.power).toBeLessThan(10);
    })
    it("Power shoule be greater than 1",function(){
        expect(app.state.power).toBeGreaterThan(1);
    })
    it("Power shoule be 5",function(){
        expect(app.state.power).toBe(5);
    })

})
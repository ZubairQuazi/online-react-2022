import ReactDOM from 'react-dom';
import MainApp from './mainapp';

ReactDOM.render(<MainApp/>, document.getElementById("root"));
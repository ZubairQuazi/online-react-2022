import { Provider } from "react-redux";
import HeroComp from "./components/heroes.components";
import HeroCompHook from "./components/heroes.component_withhooks";
import store from "./redux/store"

let MainApp = ()=>{
    return<div className="container">
                <h1>Redux 101</h1>
                <Provider store={ store }>
                    <HeroComp/>
                </Provider>
                <Provider store={ store }>
                    <HeroCompHook/>
                </Provider>
           </div>
}

export default MainApp;
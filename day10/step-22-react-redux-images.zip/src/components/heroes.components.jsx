import { Component } from "react";
import { addHero } from "../redux/index";
import { connect } from "react-redux";

const mapStateToProp = (state)=>{
    return {
        numberOfHeroes : state.numberOfHeroes
    }
}

const mapDispatchToProps = ( dispatch )=>{
    return {
        addHero : ()=> dispatch( addHero() )
    }
}

class HeroComp extends Component{
    render(){
        return <div>
            <h1>Avengers Enrollment Program</h1>
            <hr />
            <h2>Number of Avengers : { this.props.numberOfHeroes }</h2>
            <button onClick={ this.props.addHero }>Add Avenger</button>
        </div>
    }
}

export default connect(mapStateToProp, mapDispatchToProps)(HeroComp);
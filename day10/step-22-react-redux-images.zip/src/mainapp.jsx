import { Provider } from "react-redux";
import HeroComp from "./components/heroes.components";
import HeroCompHook from "./components/heroes.component_withhooks";
import store from "./redux/store";
// import avengers from "./images/avengers.png";

let MainApp = ()=>{
    return<div className="container">
                <h1>Redux 101</h1>
               {/* <img src={ avengers } width="100"/> */}
               <img src={ require('./images/avengers.png') } width="100" />
                <Provider store={ store }>
                    <HeroComp/>
                </Provider>
                <Provider store={ store }>
                    <HeroCompHook/>
                </Provider>
           </div>
}

export default MainApp;
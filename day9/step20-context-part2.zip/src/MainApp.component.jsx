import GrandParentComponent from "./components/grand.component";

let MainApp = ()=>{
    return<div className="container">
                <h1>State Management with Context API</h1>
                <hr/>
                <GrandParentComponent/>
           </div>
}

export default MainApp;
import { FamilyContext } from "../contexts/family.context";

let ChildComponent = ()=>{
    return <div style={ { border : "2px dashed grey", padding : "10px", margin : "10px"} }>
                <h2>Child Component</h2>
                <hr/>
                <FamilyContext.Consumer>{(val)=><h3>Power : { val }</h3>}</FamilyContext.Consumer>
            </div>
}

export default ChildComponent;
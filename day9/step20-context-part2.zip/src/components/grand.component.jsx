import { useRef, useState } from "react";
import { FamilyContext } from "../contexts/family.context";
import { GeneralContext } from "../contexts/general.context";
import CousinComponent from "./cousin.component";
import ParentComponent from "./parent.component";

let GrandParentComponent = ()=>{
    let [power, accessPower] = useState(0);
    let [message, setMessage] = useState("Hello from Grand Parent Component");
    let txtIP = useRef();
    return <div style={ { border : "2px dashed grey", padding : "10px", margin : "10px"} }>
                <h2>Grand Parent Component | Power { power }</h2>
                <button onClick={ ()=> accessPower( power + 1)}>Increase Power</button>
                <button onClick={ ()=> accessPower( power - 1)}>Decrease Power</button>
                <hr/>
                <input ref={ txtIP }/>
                <button onClick={ ()=> setMessage( txtIP.current.value )}>Send Message</button>
                <hr/>
               <FamilyContext.Provider value={ power }>
                   <GeneralContext.Provider value={ message }>
                        <ParentComponent/>
                        <CousinComponent/>
                   </GeneralContext.Provider>
               </FamilyContext.Provider>
            </div>
}

export default GrandParentComponent;
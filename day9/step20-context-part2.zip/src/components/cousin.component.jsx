import { useContext } from "react";
import { FamilyContext } from "../contexts/family.context";
import { GeneralContext } from "../contexts/general.context";

let CousinComponent = ()=>{
    let power = useContext(FamilyContext);
    let message = useContext(GeneralContext);
    return <div style={ { border : "2px dashed grey", padding : "10px", margin : "10px"} }>
                <h2>Cousin Component</h2>
                <hr/>
               {/*  
                <FamilyContext.Consumer>{(val)=><h3>Power : { val }</h3>}</FamilyContext.Consumer>
                <GeneralContext.Consumer>{ (val)=> <h4>Message is : { val }</h4> }</GeneralContext.Consumer> 
                */}
                <h4>Power : { power }</h4>
                <h4>Message : { message }</h4>
            </div>
}

export default CousinComponent;
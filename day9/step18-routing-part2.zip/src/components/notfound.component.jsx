let NotFoundComponent = ()=>{
    return<div>
                <h2>404 | Not Found Component</h2>
           </div>
}

export default NotFoundComponent;
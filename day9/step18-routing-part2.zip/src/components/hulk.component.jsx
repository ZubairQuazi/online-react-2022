import { useParams } from "react-router-dom";

let HulkComponent = (props)=>{
    let params = useParams();
    return<div>
                <h2>Hulk Component</h2>
                <h3>Version is {params.ver}</h3>
           </div>
}

export default HulkComponent;
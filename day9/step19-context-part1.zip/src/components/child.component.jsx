let ChildComponent = ()=>{
    return <div style={ { border : "2px dashed grey", padding : "10px", margin : "10px"} }>
                <h2>Child Component</h2>
                <hr/>
            </div>
}

export default ChildComponent;
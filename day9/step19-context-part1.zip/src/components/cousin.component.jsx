let CousinComponent = ()=>{
    return <div style={ { border : "2px dashed grey", padding : "10px", margin : "10px"} }>
                <h2>Cousin Component</h2>
                <hr/>
            </div>
}

export default CousinComponent;
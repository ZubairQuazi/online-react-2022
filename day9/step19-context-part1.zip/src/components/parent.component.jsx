import ChildComponent from "./child.component";

let ParentComponent = ()=>{
    return <div style={ { border : "2px dashed grey", padding : "10px", margin : "10px"} }>
                <h2>Parent Component</h2>
                <hr/>
                <ChildComponent/>
            </div>
}

export default ParentComponent;
import CousinComponent from "./cousin.component";
import ParentComponent from "./parent.component";

let GrandParentComponent = ()=>{
    return <div style={ { border : "2px dashed grey", padding : "10px", margin : "10px"} }>
                <h2>Grand Parent Component</h2>
                <hr/>
                <ParentComponent/>
                <CousinComponent/>
            </div>
}

export default GrandParentComponent;
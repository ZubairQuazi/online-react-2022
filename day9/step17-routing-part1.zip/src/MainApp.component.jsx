import {BrowserRouter, HashRouter, Link, Route, Routes } from "react-router-dom";
import HeroesHomeComponent from "./components/home.component";
import HulkComponent from "./components/hulk.component";
import IronmanComponent from "./components/ironman.component";
import ScarletComponent from "./components/scarlet.component";
import NotFoundComponent from "./components/notfound.component";
let MainApp = ()=>{
    return<div className="container">
                <h1>Routing 101</h1>
                <hr/>
                <BrowserRouter>
                  {/*   <ul>
                        <li><a href="/">Home</a></li>
                        <li><a href="/ironman">Ironman</a></li>
                        <li><a href="/hulk">Hulk</a></li>
                        <li><a href="/scarlet">Scarlet</a></li>
                        <li><a href="/batman">Batman</a></li>
                    </ul> */}
                    <ul className="nav justify-content-center">
                        <li className="nav-item"> <Link className="nav-link" to={"/"}>Home</Link> </li>
                        <li className="nav-item"> <Link className="nav-link" to={"/ironman"}>Ironman</Link> </li>
                        <li className="nav-item"> <Link className="nav-link" to={"/hulk"}>Hulk</Link> </li>
                        <li className="nav-item"> <Link className="nav-link" to={"/scarlet"}>Scarlet</Link> </li>
                        <li className="nav-item"> <Link className="nav-link" to={"/batman"}>Batman</Link> </li>
                    </ul>
                   <Routes>
                        <Route path="/" element={ <HeroesHomeComponent/> }/>
                        <Route path="/hulk" element={ <HulkComponent/> }/>
                        <Route path="/ironman" element={ <IronmanComponent/> }/>
                        <Route path="/scarlet" element={ <ScarletComponent/> }/>
                        <Route path="*" element={ <NotFoundComponent/> }/>
                   </Routes>
                </BrowserRouter>
           </div>
}

export default MainApp;
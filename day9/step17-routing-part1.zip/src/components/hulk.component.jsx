let HulkComponent = ()=>{
    return<div>
                <h2>Hulk Component</h2>
           </div>
}

export default HulkComponent;
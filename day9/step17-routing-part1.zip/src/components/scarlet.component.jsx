let ScarletComponent = ()=>{
    return<div>
                <h2>Scarlet Component</h2>
           </div>
}

export default ScarletComponent;
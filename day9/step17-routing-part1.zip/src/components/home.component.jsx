let HeroesHomeComponent = ()=>{
    return<div>
                <h2>Heroes Home Component</h2>
           </div>
}

export default HeroesHomeComponent;
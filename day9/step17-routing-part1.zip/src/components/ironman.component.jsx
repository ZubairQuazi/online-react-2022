let IronmanComponent = ()=>{
    return<div>
                <h2>Ironman Component</h2>
           </div>
}

export default IronmanComponent;